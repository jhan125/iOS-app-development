//
//  try.swift
//  TodoListAppTutorial
//
//  Created by Jiali Han on 4/29/25.
//


import Foundation
struct WatchKitExtension {
    var url: URL
    
}
