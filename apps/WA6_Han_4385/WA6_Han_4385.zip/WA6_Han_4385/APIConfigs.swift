//
//  APIConfigs.swift
//  WA6_Han_4385
//
//  Created by Jiali Han on 10/21/24.
//

import Foundation

class APIConfigs{
    //MARK: API base URL...
    static let baseURL = "http://apis.sakibnm.work:8888/contacts/text/"
}
