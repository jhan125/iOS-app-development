//
//  PhoneType.swift
//  WA4_Han_4385
//
//  Created by Jiali Han on 10/2/24.
//

import Foundation

class PhoneType{
    static let types = ["Cell", "Work", "Home"]
}
