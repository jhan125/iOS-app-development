//
//  DisplayDetailsViewController.swift
//  WA4_Han_4385
//
//  Created by Jiali Han on 10/2/24.
//

import UIKit

class DisplayDetailsViewController: UIViewController {

    //MARK: creating instance of DisplayView...
    let displayScreen = DisplayDetailsView();
    
    var receivedContacts: Contact = Contact()
        
    //MARK: patch the view of the controller to the DisplayView...
    override func loadView() {
        view = displayScreen
    }
    
    //MARK: information from the first screen...
    var receivedContact: Contact = Contact()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //MARK: setting the Labels' texts...
        if let unwrappedName = receivedContact.name{
            if !unwrappedName.isEmpty{
                displayScreen.labelName.text = "\(unwrappedName)"
            }
        }
        
        if let unwrappedEmail = receivedContact.email{
            if !unwrappedEmail.isEmpty{
                displayScreen.labelEmail.text = "Email: \(unwrappedEmail)"
            }
        }
        
        let unwrappedPhoneType = receivedContact.phoneType!
        let unwrappedPhoneNumber = receivedContact.phoneNumber!
        
        if !unwrappedPhoneNumber.isEmpty{
            displayScreen.labelPhone.text = "Phone: \(unwrappedPhoneNumber) (\(unwrappedPhoneType))"
        }
        
        if let unwrappedAddress = receivedContact.address{
            if !unwrappedAddress.isEmpty{
                displayScreen.labelAddress.text = "\(unwrappedAddress)"
            }
        }
        
        if let unwrappedCityAndState = receivedContact.cityAndState{
            if !unwrappedCityAndState.isEmpty{
                displayScreen.labelCityAndState.text = "\(unwrappedCityAndState)"
            }
        }
        
        if let unwrappedZip = receivedContact.zip{
            if !unwrappedZip.isEmpty{
                displayScreen.labelZip.text = "\(unwrappedZip)"
            }
        }
    }
}
