//
//  AddContactView.swift
//  WA4_Han_4385
//
//  Created by Jiali Han on 10/2/24.
//

import UIKit

class AddContactView: UIView {

    var labelTitle: UILabel!
    var textFieldName: UITextField!
    var textFieldEmail: UITextField!
    var labelAddPhoneType: UILabel!
    var pickerPhoneType: UIPickerView!
    var textFieldPhoneNumber: UITextField!
    var textFieldAddress: UITextField!
    var textFieldCityAndState: UITextField!
    var textFieldZip: UITextField!
   
   override init(frame: CGRect) {
       super.init(frame: frame)
       
       //setting the background color...
       self.backgroundColor = .white
       
       setLabelTitle()
       setTextFieldName()
       setTextFieldEmail()
       setLabelAddPhoneType()
       setPickerPhoneType()
       setTextFieldPhoneNumber()
       setTextFieldAddress()
       setTextFieldCityAndState()
       setTextFieldZip()
       
       initConstraints()
   }
   
   func setLabelTitle() {
       labelTitle = UILabel()
       // A Label displaying the text, “Add a New Contact.”
       // Make this text a little bit bigger (play with the font size).
       labelTitle.text = "Add a New Contact"
       labelTitle.font = labelTitle.font.withSize(28)
       labelTitle.textAlignment = .center;
       labelTitle.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(labelTitle)
   }
   
   func setTextFieldName() {
       textFieldName = UITextField()
       textFieldName.placeholder = "Name"
       textFieldName.borderStyle = .roundedRect
       textFieldName.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(textFieldName)
   }
   
   func setTextFieldEmail() {
       textFieldEmail = UITextField();
       textFieldEmail.placeholder = "Email"
       textFieldEmail.borderStyle = .roundedRect
       // set the keypad type of the TextField to 'emailAddress'
       textFieldEmail.keyboardType = .emailAddress
       textFieldEmail.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(textFieldEmail)
   }
   
   func setLabelAddPhoneType() {
       labelAddPhoneType = UILabel();
       labelAddPhoneType.text = "Add Phone"
       // font sizes for “Add Phone” and “Select Type” are different
       labelAddPhoneType.font = labelAddPhoneType.font.withSize(24)
       labelAddPhoneType.textAlignment = .center;
       labelAddPhoneType.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(labelAddPhoneType)
   }
   
   func setPickerPhoneType() {
       pickerPhoneType = UIPickerView();
       pickerPhoneType.isUserInteractionEnabled = true
       pickerPhoneType.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(pickerPhoneType)
   }
   
   func setTextFieldPhoneNumber() {
       textFieldPhoneNumber = UITextField();
       textFieldPhoneNumber.placeholder = "Phone number";
       textFieldPhoneNumber.borderStyle = .roundedRect
       // set the keypad type of the TextField to 'phonePad'
       textFieldPhoneNumber.keyboardType = .phonePad
       textFieldPhoneNumber.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(textFieldPhoneNumber)
   }
   
   func setTextFieldAddress() {
       textFieldAddress = UITextField();
       textFieldAddress.placeholder = "Address"
       textFieldAddress.borderStyle = .roundedRect
       textFieldAddress.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(textFieldAddress)
   }
   
   func setTextFieldCityAndState() {
       textFieldCityAndState = UITextField()
       textFieldCityAndState.placeholder = "City, State"
       textFieldCityAndState.borderStyle = .roundedRect
       textFieldCityAndState.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(textFieldCityAndState)
   }
   
   func setTextFieldZip() {
       textFieldZip = UITextField();
       textFieldZip.placeholder = "ZIP"
       textFieldZip.borderStyle = .roundedRect
       // keypad type of the TextFiles should be 'numberPad'
       textFieldZip.keyboardType = .numberPad
       textFieldZip.translatesAutoresizingMaskIntoConstraints = false;
       self.addSubview(textFieldZip)
   }
   
   func initConstraints() {
       NSLayoutConstraint.activate([
            // App Name
            labelTitle.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor, constant: 12),
            labelTitle.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
        
            // Name
            textFieldName.topAnchor.constraint(equalTo: labelTitle.bottomAnchor, constant: 32),
            textFieldName.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            textFieldName.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            textFieldName.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -24),
           
            // Email
            textFieldEmail.topAnchor.constraint(equalTo: textFieldName.bottomAnchor, constant: 16),
            textFieldEmail.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            textFieldEmail.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            textFieldEmail.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -24),
           
            // Add Phone
            labelAddPhoneType.topAnchor.constraint(equalTo: textFieldEmail.bottomAnchor, constant: 16),
            labelAddPhoneType.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            labelAddPhoneType.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            labelAddPhoneType.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -24),
           
            // Picker Phone Type
            pickerPhoneType.topAnchor.constraint(equalTo: labelAddPhoneType.bottomAnchor, constant: 16),
            pickerPhoneType.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            pickerPhoneType.heightAnchor.constraint(equalToConstant: 120),
           
            // Phone Number
            textFieldPhoneNumber.topAnchor.constraint(equalTo: pickerPhoneType.bottomAnchor, constant: 16),
            textFieldPhoneNumber.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            textFieldPhoneNumber.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            textFieldPhoneNumber.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -24),
           
            // Address
            textFieldAddress.topAnchor.constraint(equalTo: textFieldPhoneNumber.bottomAnchor, constant: 20),
            textFieldAddress.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            textFieldAddress.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            textFieldAddress.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -24),
           
            // City and State
            textFieldCityAndState.topAnchor.constraint(equalTo: textFieldAddress.bottomAnchor, constant: 20),
            textFieldCityAndState.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            textFieldCityAndState.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            textFieldCityAndState.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -24),
           
            // Zip
            textFieldZip.topAnchor.constraint(equalTo: textFieldCityAndState.bottomAnchor, constant: 20),
            textFieldZip.centerXAnchor.constraint(equalTo: self.safeAreaLayoutGuide.centerXAnchor),
            textFieldZip.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            textFieldZip.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor, constant: -24),
       ])
   }
   
   required init?(coder: NSCoder) {
       fatalError("init(coder:) has not been implemented")
   }
}
