//
//  AddContactViewController.swift
//  WA4_Han_4385
//
//  Created by Jiali Han on 10/2/24.
//

import UIKit

protocol AddContactDelegate: AnyObject {
    func didAddContact(_ contact: Contact)
}

class AddContactViewController: UIViewController {
    
    var delegate:AddContactDelegate?
    
    var selectedType = "Cell"
    
    let addContactScreen = AddContactView()
    
    
    //MARK: add the view to this controller while the view is loading...
    override func loadView() {
        view = addContactScreen
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK: adding the PickerView delegate and data source...
        addContactScreen.pickerPhoneType.delegate = self
        addContactScreen.pickerPhoneType.dataSource = self
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .save, target: self,
            action: #selector(onButtonSaveTapped)
        )
        
        //MARK: recognizing the taps on the app screen, not the keyboard...
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(hideKeyboardOnTap))
        tapRecognizer.cancelsTouchesInView = false
        view.addGestureRecognizer(tapRecognizer)
    }
    
    //MARK: Hide Keyboard...
    @objc func hideKeyboardOnTap(){
        //MARK: removing the keyboard from screen...
        view.endEditing(true)
    }
    
    //MARK: submit button tapped action...
    @objc func onButtonSaveTapped(){
        // Safely unwrapping text fields using guard
        // Reference: https://stackoverflow.com/questions/63667226/force-unwrap-after-guard-let
        guard let name = addContactScreen.textFieldName?.text, !name.isEmpty else {
           return showEmptyError(fieldName: "Name")
        }
           
        guard let email = addContactScreen.textFieldEmail?.text, !email.isEmpty else {
            return showEmptyError(fieldName: "Email")
        }
           
        guard isValidEmail(email) else {
            return showError(content: "Email address is invalid!")
        }
           
        guard let phoneNumber = addContactScreen.textFieldPhoneNumber.text, !phoneNumber.isEmpty else {
            return showEmptyError(fieldName: "PhoneNumber")
        }
        
        // phone number follows 10-digit dialing procedure
        // Reference: https://en.wikipedia.org/wiki/Ten-digit_dialing
        guard isValidPhoneNumber(phoneNumber) else {
            return showError(content: "Phone number is invalid!")
        }
           
        guard let address = addContactScreen.textFieldAddress.text, !address.isEmpty else {
            return showEmptyError(fieldName: "Address")
        }
           
        guard let cityAndState = addContactScreen.textFieldCityAndState.text, !cityAndState.isEmpty else {
            return showEmptyError(fieldName: "City, State")
        }
        
        guard isValidCityAndState(cityAndState) else {
            return showError(content: "City and State is invalid!")
        }
           
        guard let zip = addContactScreen.textFieldZip.text, !zip.isEmpty else {
            return showEmptyError(fieldName: "Zip")
        }
        
        // validate if the user put a valid zipcode (exactly five digits long, the current Zip codes in the United States range from 00001 – 99950).
        guard isValidZip(zip) else {
            return showError(content: "Zip number is invalid!")
        }
            
        // Creating the package once all validation checks are passed
        let newContact = Contact(
            name: name,
            email: email,
            phoneType: selectedType,
            phoneNumber: phoneNumber,
            address: address,
            cityAndState: cityAndState,
            zip: zip
        )
        
        // Call the delegate method to pass the new contact to Main Screen's ViewController
        delegate?.didAddContact(newContact)
           
        // Pop back to the Main Screen
        navigationController?.popViewController(animated: true)
    }

    // Helper function to show empty input error
    func showEmptyError(fieldName: String) {
        let alert = UIAlertController(title: "Error!", message: "The field \"\(fieldName)\" cannot be empty!", preferredStyle: .alert)
                
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        
        self.present(alert, animated: true)
    }

    // Helper function to show other errors
    func showError(content: String) {
        let alert = UIAlertController(title: "Error!", message: content, preferredStyle: .alert)
                
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        
        self.present(alert, animated: true)
    }
    
    // Helper function to check whether email is valid
    // Reference: https://stackoverflow.com/questions/25471114/how-to-validate-an-e-mail-address-in-swift/25471164#25471164
    func isValidEmail(_ email: String) -> Bool {
        let EMAIL_REGEX = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", EMAIL_REGEX)
        return emailPred.evaluate(with: email)
    }
    
    // Helper function to check whether phone number is valid
    // Reference: https://stackoverflow.com/questions/27998409/email-phone-validation-in-swift
    func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        // valid formats: 123-456-7890 and 1234567890
        let PHONE_REGEX = "^\\d{3}-?\\d{3}-?\\d{4}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result = phoneTest.evaluate(with: phoneNumber)
        return result
   }
    
    // Helper function to check whether city and State is valid
    // Reference: Piazza https://northeastern.instructure.com/courses/192495/external_tools/289
    func isValidCityAndState(_ cityAndState: String) -> Bool {
        // Regular expression for validating "City, State" format
        let CITY_STATE_REGEX = "^[A-Za-z]+(?:[\\s-][A-Za-z]+)*,\\s[A-Za-z]+(?:[\\s-][A-Za-z]+)*$"
        
        // NSPredicate to evaluate the string against the regex
        let cityStateTest = NSPredicate(format: "SELF MATCHES %@", CITY_STATE_REGEX)
        
        // Return true if the input matches the regex, otherwise false
        return cityStateTest.evaluate(with: cityAndState)
    }
    
    //Helper function to check whether phone number is valid
    func isValidZip(_ zip: String) -> Bool {
        // ZIP code should 5 digits long and is a valid integer.
        if let zipCode = Int(zip), zip.count == 5, zipCode <= 99950 {
            return true
        }
        return false
    }
}

//MARK: implementing phoneType PickerView...
extension AddContactViewController: UIPickerViewDelegate, UIPickerViewDataSource{
    
    //returns the number of columns/components in the Picker View...
    func numberOfComponents(in phoneTypePicker: UIPickerView) -> Int {
        return 1
    }
    
    //returns the number of rows in the current component...
    func pickerView(_ phoneTypePicker: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return PhoneType.types.count
    }
    
    //set the title of currently picked row...
    func pickerView(_ phoneTypePicker: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        // on change selection, update selectedMood...
        selectedType = PhoneType.types[row]
        return PhoneType.types[row]
    }
    
    // Update selectedType when a row is selected in the Picker View
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedType = PhoneType.types[row]
    }
}
