//
//  CoreDataExample_Han_Jiali_4385Tests.swift
//  CoreDataExample_Han_Jiali_4385Tests
//
//  Created by Jiali Han on 12/11/24.
//

import Testing
@testable import CoreDataExample_Han_Jiali_4385

struct CoreDataExample_Han_Jiali_4385Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
