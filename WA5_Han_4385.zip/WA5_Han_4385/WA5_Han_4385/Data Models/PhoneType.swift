//
//  PhoneType.swift
//  WA5_Han_4385
//
//  Created by Jiali Han on 10/11/24.
//

import Foundation

class PhoneType{
    static let types = ["Cell", "Work", "Home"]
}
